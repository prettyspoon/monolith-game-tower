import * as THREE from 'three';
import { STLExporter } from 'three/addons/exporters/STLExporter.js';
import { writeFileSync, mkdirSync } from 'node:fs';

const scene = new THREE.Scene();
const add = (geometry, position = [0, 0, 0]) => {
  const mesh = new THREE.Mesh(geometry, new THREE.MeshBasicMaterial());
  mesh.position.set(...position);
  scene.add(mesh);
};
const s = 70;
const offset = 1.57 * s;
const pts = (values) => values.map(([x, y]) => new THREE.Vector2(x * s, y * s));

// Three independent hollow cylindrical drawer shells preserve the queen profile when closed.
const drawers = [
  { y: -1.33, h: 0.44, bottom: 0.72, top: 0.54, inner: 0.41 },
  { y: -0.88, h: 0.42, bottom: 0.54, top: 0.46, inner: 0.35 },
  { y: -0.45, h: 0.4, bottom: 0.46, top: 0.37, inner: 0.29 },
];
for (const d of drawers) {
  add(
    new THREE.LatheGeometry(
      pts([
        [d.bottom, d.y - d.h / 2],
        [d.top, d.y + d.h / 2],
        [d.inner, d.y + d.h / 2],
        [d.inner, d.y - d.h / 2],
        [d.bottom, d.y - d.h / 2],
      ]),
      96,
    ),
    [0, offset, 0],
  );
  add(
    new THREE.CylinderGeometry(
      (d.inner - 0.025) * s,
      (d.inner - 0.025) * s,
      3.5,
      64,
    ),
    [0, (d.y - d.h / 2 + 0.025) * s + offset, 0],
  );
}

// Fixed upper stem, base, central drawer spindle, and recognizable queen crown.
add(
  new THREE.LatheGeometry(
    pts([
      [0.37, -0.32],
      [0.34, -0.16],
      [0.3, 0.09],
      [0.29, 0.32],
    ]),
    96,
  ),
  [0, offset, 0],
);
add(new THREE.CylinderGeometry(52.5, 52.5, 5.6, 80), [0, 2.8, 0]);
add(new THREE.CylinderGeometry(5.6, 5.6, 182, 40), [0, offset - 14, 0]);
add(
  new THREE.LatheGeometry(
    pts([
      [0.25, 1.18],
      [0.38, 1.23],
      [0.5, 1.43],
      [0.44, 1.68],
      [0.27, 1.85],
      [0.18, 1.91],
      [0.17, 2.05],
      [0.28, 2.15],
      [0.21, 2.29],
      [0, 2.35],
    ]),
    96,
  ),
  [0, offset, 0],
);

// Three 2.7 mm double-sided inserts and a 3.85 mm reversible chess/dice tray.
for (const y of [0.66, 0.75, 0.84])
  add(new THREE.BoxGeometry(117.6, 2.7, 117.6), [0, y * s + offset, 0]);
add(new THREE.BoxGeometry(127.4, 3.85, 127.4), [0, 0.93 * s + offset, 0]);

// Continuous one-inch-deep bent-wood border faces down in chess mode.
const railY = (0.93 - 0.19) * s + offset;
add(new THREE.BoxGeometry(127.4, 25.4, 4.2), [0, railY, 62.6]);
add(new THREE.BoxGeometry(127.4, 25.4, 4.2), [0, railY, -62.6]);
add(new THREE.BoxGeometry(4.2, 25.4, 119, 0), [62.6, railY, 0]);
add(new THREE.BoxGeometry(4.2, 25.4, 119, 0), [-62.6, railY, 0]);

scene.updateMatrixWorld(true);
const stl = new STLExporter().parse(scene, { binary: false });
mkdirSync('../outputs', { recursive: true });
writeFileSync('../outputs/monolith-game-tower.stl', stl);
