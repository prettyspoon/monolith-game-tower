'use client';

import { Canvas, useFrame } from '@react-three/fiber';
import { ContactShadows, Edges, OrbitControls } from '@react-three/drei';
import * as THREE from 'three';
import { useMemo, useRef } from 'react';

type Props = {
  exploded: boolean;
  storageOpen: boolean;
  surfaceIndex: number;
};
const ink = '#161616';

function SurfacePattern({
  kind,
  bottom = false,
}: {
  kind: number;
  bottom?: boolean;
}) {
  const y = bottom ? -0.033 : 0.033;
  const rotation: [number, number, number] = bottom
    ? [Math.PI, 0, 0]
    : [0, 0, 0];
  if (kind === 1) return null;
  if (kind === 0)
    return (
      <group position={[0, y, 0]} rotation={rotation}>
        {Array.from({ length: 64 }, (_, i) => {
          const x = i % 8,
            z = Math.floor(i / 8);
          return (x + z) % 2 === 0 ? (
            <mesh key={i} position={[(x - 3.5) * 0.185, 0, (z - 3.5) * 0.185]}>
              <boxGeometry args={[0.18, 0.004, 0.18]} />
              <meshBasicMaterial color={ink} />
            </mesh>
          ) : null;
        })}
      </group>
    );
  if (kind === 2)
    return (
      <group position={[0, y, 0]} rotation={rotation}>
        {Array.from({ length: 52 }, (_, i) => {
          const row = Math.floor(i / 13) - 1.5,
            col = (i % 13) - 6;
          if (Math.abs(row) > 0.6 && Math.abs(col) > 1.4) return null;
          return (
            <mesh key={i} position={[col * 0.115, 0, row * 0.31]}>
              <boxGeometry args={[0.105, 0.007, 0.105]} />
              <meshBasicMaterial color={ink} />
            </mesh>
          );
        })}
      </group>
    );
  if (kind === 3)
    return (
      <group position={[0, y, 0]} rotation={rotation}>
        {Array.from({ length: 81 }, (_, i) => {
          const row = Math.floor(i / 9) - 4,
            col = (i % 9) - 4;
          if (Math.abs(row) + Math.abs(col) > 6) return null;
          return (
            <mesh key={i} position={[col * 0.15 + row * 0.075, 0, row * 0.13]}>
              <sphereGeometry args={[0.032, 10, 10]} />
              <meshBasicMaterial color={ink} />
            </mesh>
          );
        })}
      </group>
    );
  if (kind === 4)
    return (
      <group position={[0, y, 0]} rotation={rotation}>
        {Array.from({ length: 24 }, (_, i) => {
          const top = i < 12;
          return (
            <mesh
              key={i}
              position={[((i % 12) - 5.5) * 0.125, 0, top ? 0.45 : -0.45]}
              rotation={[-Math.PI / 2, 0, top ? 0 : Math.PI]}
            >
              <circleGeometry args={[0.22, 3]} />
              <meshBasicMaterial
                color={i % 2 ? ink : '#777'}
                side={THREE.DoubleSide}
              />
            </mesh>
          );
        })}
      </group>
    );
  if (kind === 5)
    return (
      <group position={[0, y, 0]} rotation={rotation}>
        {[0.34, 0.64, 0.96].map((s) => (
          <mesh key={s} rotation={[-Math.PI / 2, 0, Math.PI / 4]}>
            <ringGeometry args={[s - 0.012, s + 0.012, 4]} />
            <meshBasicMaterial color={ink} side={THREE.DoubleSide} />
          </mesh>
        ))}
      </group>
    );
  if (kind === 6) {
    const cells = [
      [-2, 0],
      [-1, -1],
      [-1, 1],
      [0, -2],
      [0, 0],
      [0, 2],
      [1, -1],
      [1, 1],
      [2, 0],
      [-2, -2],
      [-2, 2],
      [2, -2],
      [2, 2],
      [-1, -3],
      [-1, 3],
      [1, -3],
      [1, 3],
      [0, -4],
      [0, 4],
    ];
    return (
      <group position={[0, y, 0]} rotation={rotation}>
        {cells.map(([r, c], i) => (
          <mesh
            key={i}
            position={[c * 0.18, 0, r * 0.155]}
            rotation={[-Math.PI / 2, 0, 0]}
          >
            <ringGeometry args={[0.135, 0.145, 6]} />
            <meshBasicMaterial color={ink} side={THREE.DoubleSide} />
          </mesh>
        ))}
      </group>
    );
  }
  return (
    <group position={[0, y, 0]} rotation={rotation}>
      {Array.from({ length: 10 }, (_, i) => (
        <group key={i}>
          <mesh position={[(i - 4.5) * 0.16, 0, 0]}>
            <boxGeometry args={[i % 3 === 0 ? 0.014 : 0.007, 0.006, 1.44]} />
            <meshBasicMaterial color={ink} />
          </mesh>
          <mesh position={[0, 0, (i - 4.5) * 0.16]}>
            <boxGeometry args={[1.44, 0.006, i % 3 === 0 ? 0.014 : 0.007]} />
            <meshBasicMaterial color={ink} />
          </mesh>
        </group>
      ))}
    </group>
  );
}

function ReversibleInsert({
  index,
  y,
  faces,
  flipped,
  active,
  exploded,
}: {
  index: number;
  y: number;
  faces: [number, number];
  flipped: boolean;
  active: boolean;
  exploded: boolean;
}) {
  const ref = useRef<THREE.Group>(null);
  useFrame((_, delta) => {
    if (!ref.current) return;
    const e = 1 - Math.exp(-delta * 7);
    ref.current.rotation.x = THREE.MathUtils.lerp(
      ref.current.rotation.x,
      flipped ? Math.PI : 0,
      e,
    );
    const targetX = exploded ? (index % 2 ? -2.05 : 2.05) : 0;
    const targetY = exploded ? y + (3 - index) * 0.18 : active ? 0.98 : y;
    ref.current.position.x = THREE.MathUtils.lerp(
      ref.current.position.x,
      targetX,
      e,
    );
    ref.current.position.y = THREE.MathUtils.lerp(
      ref.current.position.y,
      targetY,
      e,
    );
  });
  return (
    <group ref={ref} position={[0, y, 0]}>
      <mesh castShadow receiveShadow>
        <boxGeometry args={[1.68, 0.038, 1.68]} />
        <meshStandardMaterial
          color={active ? '#f3f3ee' : '#b9b2a5'}
          roughness={0.76}
        />
        <Edges color={ink} threshold={10} />
      </mesh>
      <SurfacePattern kind={faces[0]} />
      <SurfacePattern kind={faces[1]} bottom />
    </group>
  );
}

function TopTray({
  flipped,
  active,
  exploded,
  replaced,
}: {
  flipped: boolean;
  active: boolean;
  exploded: boolean;
  replaced: boolean;
}) {
  const ref = useRef<THREE.Group>(null);
  useFrame((_, delta) => {
    if (!ref.current) return;
    const e = 1 - Math.exp(-delta * 7);
    ref.current.rotation.x = THREE.MathUtils.lerp(
      ref.current.rotation.x,
      flipped ? Math.PI : 0,
      e,
    );
    const targetX = !exploded && replaced ? -2.15 : 0;
    const targetY = exploded ? 1.38 : replaced ? 1.16 : 0.93;
    ref.current.position.x = THREE.MathUtils.lerp(
      ref.current.position.x,
      targetX,
      e,
    );
    ref.current.position.y = THREE.MathUtils.lerp(
      ref.current.position.y,
      targetY,
      e,
    );
  });
  const rail = '#a9a08f';
  return (
    <group ref={ref} position={[0, 0.93, 0]}>
      <mesh castShadow receiveShadow>
        <boxGeometry args={[1.82, 0.055, 1.82]} />
        <meshStandardMaterial
          color={active ? '#f4f1e8' : '#c3baaa'}
          roughness={0.72}
        />
        <Edges color={ink} threshold={10} />
      </mesh>
      <SurfacePattern kind={0} />
      <group position={[0, -0.19, 0]}>
        <mesh position={[0, 0, 0.89]}>
          <boxGeometry args={[1.82, 0.36, 0.06]} />
          <meshStandardMaterial color={rail} roughness={0.7} />
          <Edges color={ink} />
        </mesh>
        <mesh position={[0, 0, -0.89]}>
          <boxGeometry args={[1.82, 0.36, 0.06]} />
          <meshStandardMaterial color={rail} roughness={0.7} />
          <Edges color={ink} />
        </mesh>
        <mesh position={[0.89, 0, 0]}>
          <boxGeometry args={[0.06, 0.36, 1.7]} />
          <meshStandardMaterial color={rail} roughness={0.7} />
          <Edges color={ink} />
        </mesh>
        <mesh position={[-0.89, 0, 0]}>
          <boxGeometry args={[0.06, 0.36, 1.7]} />
          <meshStandardMaterial color={rail} roughness={0.7} />
          <Edges color={ink} />
        </mesh>
      </group>
    </group>
  );
}

const drawerData = [
  {
    y: -1.33,
    h: 0.44,
    bottom: 0.72,
    top: 0.54,
    inner: 0.41,
  },
  {
    y: -0.88,
    h: 0.42,
    bottom: 0.54,
    top: 0.46,
    inner: 0.35,
  },
  {
    y: -0.45,
    h: 0.4,
    bottom: 0.46,
    top: 0.37,
    inner: 0.29,
  },
];
function Drawer({
  index,
  storageOpen,
  exploded,
}: {
  index: number;
  storageOpen: boolean;
  exploded: boolean;
}) {
  const ref = useRef<THREE.Group>(null),
    d = drawerData[index];
  const shell = useMemo(
    () =>
      new THREE.LatheGeometry(
        [
          new THREE.Vector2(d.bottom, -d.h / 2),
          new THREE.Vector2(d.top, d.h / 2),
          new THREE.Vector2(d.inner, d.h / 2),
          new THREE.Vector2(d.inner, -d.h / 2),
          new THREE.Vector2(d.bottom, -d.h / 2),
        ],
        96,
      ),
    [d],
  );
  useFrame((_, delta) => {
    if (!ref.current) return;
    const e = 1 - Math.exp(-delta * 5.5);
    const sign = index % 2 ? 1 : -1;
    const pivotX = sign * d.bottom;
    const explodeX = exploded ? sign * (1.3 + index * 0.35) : 0;
    const explodeY = exploded ? (index - 1) * 0.34 : 0;
    ref.current.position.x = THREE.MathUtils.lerp(
      ref.current.position.x,
      pivotX + explodeX,
      e,
    );
    ref.current.position.y = THREE.MathUtils.lerp(
      ref.current.position.y,
      d.y + explodeY,
      e,
    );
    ref.current.rotation.y = THREE.MathUtils.lerp(
      ref.current.rotation.y,
      storageOpen ? sign * 1.35 : 0,
      e,
    );
  });
  const sign = index % 2 ? 1 : -1;
  const pivotX = sign * d.bottom;
  return (
    <group ref={ref} position={[pivotX, d.y, 0]}>
      <group position={[-pivotX, 0, 0]}>
        <mesh castShadow geometry={shell}>
          <meshStandardMaterial
            color="#111"
            roughness={0.36}
            side={THREE.DoubleSide}
          />
          <Edges color="#3c3c3c" threshold={24} />
        </mesh>
        <mesh position={[0, -d.h / 2 + 0.025, 0]}>
          <cylinderGeometry
            args={[d.inner - 0.025, d.inner - 0.025, 0.05, 64]}
          />
          <meshStandardMaterial color="#242424" />
        </mesh>
        {(storageOpen || exploded) &&
          Array.from({ length: 8 }, (_, i) => (
            <mesh
              key={i}
              position={[
                ((i % 4) - 1.5) * 0.12,
                -d.h / 2 + 0.065,
                (Math.floor(i / 4) - 0.5) * 0.12,
              ]}
            >
              <cylinderGeometry args={[0.045, 0.045, 0.035, 20]} />
              <meshStandardMaterial color={i % 2 ? '#e7e7df' : '#777'} />
            </mesh>
          ))}
      </group>
    </group>
  );
}

function Sculpture(props: Props) {
  const { exploded, storageOpen, surfaceIndex } = props;
  const activeLayer = Math.floor(surfaceIndex / 2);
  const activeFace = surfaceIndex % 2;
  const group = useRef<THREE.Group>(null);
  useFrame((_, d) => {
    if (group.current && !storageOpen) group.current.rotation.y += d * 0.045;
  });
  const fixedBody = useMemo(
    () =>
      [
        [0.37, -0.24],
        [0.34, -0.08],
        [0.3, 0.17],
        [0.29, 0.4],
      ].map(([x, y]) => new THREE.Vector2(x, y)),
    [],
  );
  const crown = useMemo(
    () =>
      [
        [0.25, 1.18],
        [0.38, 1.23],
        [0.5, 1.43],
        [0.44, 1.68],
        [0.27, 1.85],
        [0.18, 1.91],
        [0.17, 2.05],
        [0.28, 2.15],
        [0.21, 2.29],
        [0, 2.35],
      ].map(([x, y]) => new THREE.Vector2(x, y)),
    [],
  );
  return (
    <group ref={group} position={[0, -0.25, 0]}>
      <mesh position={[0, -0.08, 0]}>
        <latheGeometry args={[fixedBody, 96]} />
        <meshStandardMaterial color="#111" />
      </mesh>
      <mesh castShadow position={[0, exploded ? 0.8 : 0, 0]}>
        <latheGeometry args={[crown, 96]} />
        <meshStandardMaterial color="#111" roughness={0.3} />
        <Edges color="#444" threshold={25} />
      </mesh>
      <mesh position={[0, -0.54, 0]}>
        <cylinderGeometry args={[0.08, 0.08, 2.05, 32]} />
        <meshStandardMaterial color="#575757" />
      </mesh>
      {drawerData.map((_, i) => (
        <Drawer
          key={i}
          index={i}
          storageOpen={storageOpen}
          exploded={exploded}
        />
      ))}
      <mesh position={[0, -1.57, 0]}>
        <cylinderGeometry args={[0.75, 0.75, 0.08, 80]} />
        <meshStandardMaterial color="#111" />
      </mesh>
      <ReversibleInsert
        index={3}
        y={0.66}
        faces={[6, 7]}
        flipped={activeLayer === 3 && activeFace === 1}
        active={activeLayer === 3}
        exploded={exploded}
      />
      <ReversibleInsert
        index={2}
        y={0.75}
        faces={[4, 5]}
        flipped={activeLayer === 2 && activeFace === 1}
        active={activeLayer === 2}
        exploded={exploded}
      />
      <ReversibleInsert
        index={1}
        y={0.84}
        faces={[2, 3]}
        flipped={activeLayer === 1 && activeFace === 1}
        active={activeLayer === 1}
        exploded={exploded}
      />
      <TopTray
        flipped={activeLayer === 0 && activeFace === 1}
        active={activeLayer === 0}
        exploded={exploded}
        replaced={activeLayer > 0}
      />
    </group>
  );
}

export default function ModelStage(props: Props) {
  return (
    <Canvas
      shadows
      camera={{ position: [4.6, 3.1, 6.2], fov: 34 }}
      dpr={[1, 2]}
    >
      <color attach="background" args={['#deded8']} />
      <ambientLight intensity={1.4} />
      <directionalLight castShadow position={[4, 7, 5]} intensity={2.8} />
      <directionalLight position={[-4, 2, -3]} intensity={1.1} />
      <Sculpture {...props} />
      <ContactShadows
        position={[0, -1.86, 0]}
        opacity={0.35}
        scale={10}
        blur={2.5}
      />
      <OrbitControls
        makeDefault
        enablePan={false}
        minDistance={4}
        maxDistance={10}
        target={[0, 0.05, 0]}
        minPolarAngle={0.45}
        maxPolarAngle={Math.PI / 2.05}
      />
    </Canvas>
  );
}
