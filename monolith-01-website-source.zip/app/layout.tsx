import type { Metadata } from 'next';
import { Geist, Geist_Mono } from 'next/font/google';
import './globals.css';

const geistSans = Geist({
  variable: '--font-geist-sans',
  subsets: ['latin'],
});

const geistMono = Geist_Mono({
  variable: '--font-geist-mono',
  subsets: ['latin'],
});

export const metadata: Metadata = {
  metadataBase: new URL('https://monolith-game-tower.pethad661320.chatgpt.site'),
  title: 'Monolith 01 — Multi-Board Game Structure',
  description: 'An interactive 3D study of a chess queen transformed into a compact three-game structure.',
  openGraph: {
    title: 'MONOLITH / 01',
    description: 'ONE FORM. THREE GAMES.',
    images: ['/og.png'],
  },
  twitter: {
    card: 'summary_large_image',
    title: 'MONOLITH / 01',
    description: 'ONE FORM. THREE GAMES.',
    images: ['/og.png'],
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en">
      <body
        className={`${geistSans.variable} ${geistMono.variable} antialiased`}
      >
        {children}
      </body>
    </html>
  );
}
