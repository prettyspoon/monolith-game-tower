'use client';

import dynamic from 'next/dynamic';
import {
  Box,
  FlipHorizontal2,
  Layers3,
  PackageOpen,
  RotateCcw,
} from 'lucide-react';
import { useState } from 'react';

const ModelStage = dynamic(() => import('@/components/model-stage'), {
  ssr: false,
});
const layers = [
  { label: 'TOP TRAY', faces: ['Chess', 'Blank dice tray'] },
  { label: 'INSERT 01', faces: ['Ludo', 'Chinese Checkers'] },
  { label: 'INSERT 02', faces: ['Backgammon', "Nine Men's Morris"] },
  { label: 'INSERT 03', faces: ['Catan Hexagons', '9×9 Ultimate Sudoku'] },
];

export default function Home() {
  const [exploded, setExploded] = useState(false);
  const [storageOpen, setStorageOpen] = useState(false);
  const [surfaceIndex, setSurfaceIndex] = useState(0);
  const [resetKey, setResetKey] = useState(0);
  const activeLayer = Math.floor(surfaceIndex / 2);
  const activeFace = surfaceIndex % 2;
  const activeSurface = layers[activeLayer].faces[activeFace];
  const chooseLayer = (index: number) =>
    setSurfaceIndex((current) =>
      Math.floor(current / 2) === index
        ? index * 2 + (current % 2 ? 0 : 1)
        : index * 2,
    );

  return (
    <main className="shell">
      <header className="topbar">
        <a className="brand" href="#top" aria-label="Monolith home">
          <span className="brand-mark">
            <i />
            <i />
            <i />
          </span>
          <span>MONOLITH / 01</span>
        </a>
        <p>ART 409 · OBJECT STUDY</p>
        <span className="status">
          <i /> INTERACTIVE MODEL
        </span>
      </header>
      <section id="top" className="hero">
        <div className="copy-panel">
          <p className="eyebrow">REVERSIBLE MULTI-BOARD SYSTEM</p>
          <h1>
            ONE FORM.
            <br />
            <em>SEVEN GAMES.</em>
          </h1>
          <p className="lede">
            A sofa-height side table that transforms into a seven-game console.
            Its tray holds everyday essentials, while rotating storage keeps
            cards, dice and playing pieces organized inside the queen.
          </p>
          <div className="games" aria-label="Choose board layer">
            {layers.map((layer, index) => (
              <button
                key={layer.label}
                className={activeLayer === index ? 'game active' : 'game'}
                onClick={() => chooseLayer(index)}
              >
                <span>0{index + 1}</span>
                <b>
                  <small>{layer.label}</small>
                  {activeLayer === index
                    ? layer.faces[activeFace]
                    : `${layer.faces[0]} / ${layer.faces[1]}`}
                </b>
                <i aria-hidden="true">FLIP</i>
              </button>
            ))}
          </div>
          <div className="material-note">
            <span>TOP RIM</span>
            <b>1 IN KERF-BENT PLY</b>
            <span>INSERTS</span>
            <b>DOUBLE-SIDED ENGRAVED</b>
          </div>
        </div>
        <div className="model-panel">
          <div className="model-meta">
            <span>DRAG TO ORBIT</span>
            <span>SELECT + FLIP A LAYER</span>
          </div>
          <ModelStage
            key={resetKey}
            exploded={exploded}
            storageOpen={storageOpen}
            surfaceIndex={surfaceIndex}
          />
          <div className="model-caption">
            <span className="caption-number">0{activeLayer + 1}</span>
            <div>
              <small>ACTIVE SURFACE</small>
              <strong>{activeSurface}</strong>
            </div>
          </div>
        </div>
      </section>
      <section className="control-bar" aria-label="Model controls">
        <button
          onClick={() => setExploded(!exploded)}
          className={exploded ? 'selected' : ''}
        >
          <Layers3 size={17} />
          {exploded ? 'ASSEMBLE' : 'EXPLODE VIEW'}
        </button>
        <button onClick={() => setSurfaceIndex((index) => (index + 1) % 8)}>
          <FlipHorizontal2 size={17} />
          FLIP GAME BOARD
        </button>
        <button
          onClick={() => setStorageOpen(!storageOpen)}
          className={storageOpen ? 'selected' : ''}
        >
          <PackageOpen size={17} />
          {storageOpen ? 'CLOSE STORAGE' : 'OPEN STORAGE'}
        </button>
        <button onClick={() => setResetKey((n) => n + 1)}>
          <RotateCcw size={17} />
          RESET VIEW
        </button>
        <a href="mailto:?subject=Monolith%2001%20Design%20Inquiry">
          CONTACT DESIGNER
        </a>
        <span>
          <Box size={16} />
          <span className="size-readout">
            420 × 420 × 620 MM
            <small>1.5 × 1.5 × 2 FT</small>
          </span>
        </span>
      </section>
      <section className="concept">
        <p className="eyebrow">BOARD LOGIC</p>
        <div className="concept-grid">
          <h2>
            Flip. Stack.
            <br />
            <em>Contain.</em>
          </h2>
          <p>
            Designed at side-table height, the queen works beside a sofa or
            lounge chair as a surface for drinks and phones. When it is time to
            play, the tray and reversible inserts turn it into a compact gaming
            console, with rotating storage for cards, dice and game pieces.
          </p>
          <ol>
            <li>
              <span>01</span>CHESS / DICE TRAY
            </li>
            <li>
              <span>02</span>THREE REVERSIBLE INSERTS
            </li>
            <li>
              <span>03</span>SEVEN GAME SURFACES
            </li>
          </ol>
        </div>
      </section>
    </main>
  );
}
